package com.capgemini.contactbook.test;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookServiceTest {
	static ContactBookService contactBookService;
	@BeforeClass
	public static void setUpTestEnv(){
		contactBookService = new ContactBookServiceImpl();
	}
	@Before
	public void setUpMockDataForTest(){}
	@Test(expected=ContactBookException.class)
	public void getEnquiryDetailsTest() throws SQLException {
		System.out.println("Test GetEnquiryDetails implemented");
		contactBookService.getEnquiryDetails(11);
	}
	@Test(expected=ContactBookException.class)
	public void addEnquiryTest() throws SQLException, ContactBookException {
		System.out.println("Test AddEnquiry implemented");
//		EnquiryBean enqry = new EnquiryBean("Ranbir", "Gupta", "9898990004", "Pune", "Java");
//		contactBookService.addEnquiry(enqry);
//		Assert.assertEquals(expected, actual);
	}
	@After
	public void tearDownDataForTest(){}
	@AfterClass
	public static void tearDownTest(){
		contactBookService = null;
	}
}